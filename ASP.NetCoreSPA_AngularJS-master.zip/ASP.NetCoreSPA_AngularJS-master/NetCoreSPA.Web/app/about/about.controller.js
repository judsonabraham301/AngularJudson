
templatingApp.controller('AboutController', ['$scope', '$http', function ($scope, $http) {
    $scope.title = "About Page";
}]);
