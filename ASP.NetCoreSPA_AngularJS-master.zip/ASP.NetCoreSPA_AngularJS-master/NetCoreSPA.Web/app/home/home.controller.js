
templatingApp.controller('HomeController', ['$scope', function ($scope) {
    $scope.message = "Welcome to ASP.NET Core!";
}]);
